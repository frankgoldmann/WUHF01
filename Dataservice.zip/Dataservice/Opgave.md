##### WU HF 01 v/Frank - april 2019
# Dataservice opgave uge 2
Vi har i ugens løb arbejdet med API'er, Express, routes, database, masser SQL og fetch.

Den sidste dag fredag den 12. april skal vi have bundet det hele sammen. I er startet på opgaven, så nu skal den gøres færdig. Jeg regner med at vi bruger 2-3 lektioner på opgaven.

> Opgaven går ud på at I laver et lille site som via fetch henter data fra jeres eget api.

> Brug databasen Birgers_bolcher, som via routes leverer dataen.

> Opret en html webside med en dropdown til farver, hvor farverne hentes vha. et fetch til eget api.

> Når siden vises skal alle bolcher udskrives på siden

> Når man vælger en farve fra listen skal kun bolcher med den farve vises.

> Opret et søgefelt og en søgeknap, hvor man kan skrive en del af et bolches navn hvorefter bolcherne udskrives.

> Fritekstsøgning og den med farve var blot 2 eksempler. Find selv på flere...


*God fornøjelse*

*Frank*
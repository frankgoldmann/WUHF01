document.addEventListener("DOMContentLoaded", function () {

    let selectfarve = document.querySelector("#selectFarve");
    let output = document.querySelector("#output");

    hentAlleBolcher(output);
    fyldFarveIDropdown(selectfarve);


    selectfarve.addEventListener("change", function(){
        if(selectfarve.value>0){
            hentAlleIEnFarve(selectfarve, output);
        }else{
            hentAlleBolcher(output)
        }
      
    })



})

function hentAlleIEnFarve(selectfarve, output) {
    fetch('http://localhost:3333/getAll/' + selectfarve.value)
        .then(function (result) {
            return result.json();
        })
        .then(function (data) {
            output.innerHTML = "";
            data.forEach((bolche) => {
                console.log('bolche.navn :', bolche.Navn);
                output.innerHTML += bolche.Navn + " " + bolche.Farve + "<br>";
            });
        });
}

function hentAlleBolcher(output) {
    fetch('http://localhost:3333/getAll')
        .then(function (result) {
            return result.json();
        })
        .then(function (data) {
            data.forEach((bolche) => {
                console.log('bolche.navn :', bolche.Navn);
                output.innerHTML += bolche.Navn + " " + bolche.Farve + "<br>";
            });
        });
}

function fyldFarveIDropdown(selectfarve) {
    fetch('http://localhost:3333/getColors')
        .then(function (result) {
            return result.json();
        })
        .then(function (data) {
            data.forEach((farve) => {
                let option = document.createElement("option");
                option.value = farve.id;
                option.innerHTML = farve.navn;
                selectfarve.appendChild(option);
            });
        });
}

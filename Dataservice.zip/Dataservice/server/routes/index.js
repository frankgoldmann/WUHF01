const mysql = require('mysql2');

const db = mysql.createConnection({
    'host': 'localhost',
    'user': 'root',
    'password': '',
    'database': 'birgers_bolcher'
});


module.exports = function (app) {

    // app.get('/', function (req, res) {
    //     res.send("Frank")
    // });

    // app.get('/getUser', function (req, res) {
    //     let user = {
    //         "firstname": "Frank",
    //         "lastname": "Goldmann"
    //     }
    //     res.send(user)
    // })

    app.get('/getAll', function (req, res) {
        //#region mit sql
        const sql = `-- select felter
        SELECT 
        bolche.navn as Navn,
        farve.navn as Farve,
        smag.navn as Smag,
        styrke.navn as Styrke,
        surhed.navn as Surhed,
        bolche.pris as Pris,
        bolche.vaegt as Vægt
        FROM bolche
        
        -- join tabellerne
        
        inner JOIN farve
        on bolche.fk_farve = farve.id
        
        inner JOIN smag
        on bolche.fk_smag = smag.id
        
        inner JOIN styrke
        on bolche.fk_styrke = styrke.id
        
        inner JOIN surhed
        on bolche.fk_surhed = surhed.id
        `

        //#endregion
        db.query(sql, function (err, rows) {
            if (err) {
                res.send(err)
            } else {
                res.send(rows)
            }
        })
    })

    app.get('/getAll/:farve', function (req, res) {
        //#region mit sql
        const sql = `-- select felter
        SELECT 
        bolche.navn as Navn,
        farve.navn as Farve,
        smag.navn as Smag,
        styrke.navn as Styrke,
        surhed.navn as Surhed,
        bolche.pris as Pris,
        bolche.vaegt as Vægt
        FROM bolche
        
        -- join tabellerne
        
        inner JOIN farve
        on bolche.fk_farve = farve.id
        
        inner JOIN smag
        on bolche.fk_smag = smag.id
        
        inner JOIN styrke
        on bolche.fk_styrke = styrke.id
        
        inner JOIN surhed
        on bolche.fk_surhed = surhed.id

        where bolche.fk_farve = ?
        `

        //#endregion
        db.query(sql,[req.params.farve], function (err, rows) {
            if (err) {
                res.send(err)
            } else {
                res.send(rows)
            }
        })
    })


    app.get('/getUser/:id', function (req, res) {
        db.query('SELECT * FROM bruger where id = ?',[req.params.id], function (err, rows) {
            if (err) {
                res.send(err)
            } else {
                res.send(rows)
            }
        })
    })

    app.get('/getColors', function (req, res) {
        db.query('SELECT * FROM farve', function (err, rows) {
            if (err) {
                res.send(err)
            } else {
                res.send(rows)
            }
        })
    })
}